def naloga2(znacilke: dict, razredi: list, koraki: int) -> tuple:

    entropija = float('inf')
    tocnost = float('inf')

    # Napisite svojo kodo tukaj

    return (entropija, tocnost)
